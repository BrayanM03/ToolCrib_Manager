
<?php
define("SERVIDOR","localhost");
define("BD","toolcrib_manager");
define("USUARIO","root");
define("PASS","");